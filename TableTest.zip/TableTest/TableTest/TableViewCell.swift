//
//  TableViewCell.swift
//  TableTest
//
//  Created by Germán Santos Jaimes on 5/26/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class TestTableViewCell: UITableViewCell {

    
    
}
