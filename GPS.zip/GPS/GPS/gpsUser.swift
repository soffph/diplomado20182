//
//  gpsUser.swift
//  GPS
//
//  Created by Germán Santos Jaimes on 5/23/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import Foundation

class GPSUser{
    
    let idUser: String
    let latitude: String
    let longitude: String
    
    init(idUser: String, latitude: String, longitude: String){
        self.idUser = idUser
        self.latitude = latitude
        self.longitude = latitude
    }
}
