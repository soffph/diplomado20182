//
//  ListaTableTableViewController.swift
//  GPS
//
//  Created by Germán Santos Jaimes on 5/23/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase

class ListaTableTableViewController: UITableViewController {
    var ref : DatabaseReference!
    var handler : DatabaseHandle!
    
    
    var listUsers = [GPSUser]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "reuseIdentifier")

        ref = Database.database().reference()
        handler = ref.child("users").observe(DataEventType.value, with: { (snapshot) in
            
            var temporal = [GPSUser]()
            for user in snapshot.children.allObjects as! [DataSnapshot]{
                let data = user.value as? [String: String]
               
                if let idUser = data!["idUser"], let latitude = data!["latitude"], let longitude = data!["longitude"]{
                    temporal.append(GPSUser(idUser: idUser, latitude: latitude, longitude: longitude))
                }
                
            }
            self.listUsers = temporal
            self.tableView.reloadData()
        })
    }

    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return listUsers.count
    }

   
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        let user = listUsers[indexPath.row]
        cell.textLabel?.text = "\(user.idUser) : \(user.latitude) - \(user.longitude)"
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
 
}
