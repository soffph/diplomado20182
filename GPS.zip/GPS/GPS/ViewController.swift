//
//  ViewController.swift
//  GPS
//
//  Created by Germán Santos Jaimes on 5/23/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import CoreLocation
import Firebase

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    var ref : DatabaseReference!

    
    
    // Este objeto nos dará información sobre la localización, Celular, Wifi & GPS
    let locationManager = CLLocationManager()
    
    // Este objeto nos dara la latitude, longitude, altitude, velocidad, tiempo
    var location: CLLocation?
    
    // Manejo de errores
    var updatingLocation = false
    var lastLocationError: Error?

    let latitudeLabel : UILabel = {
        let lb = UILabel()
        lb.text = "Latitud: "
        lb.font = UIFont(name: "Arial", size: 20)
        lb.textAlignment = .right
        
        
        // Habilitamos el uso de constraints
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    let latitudeActual : UILabel = {
        let lb = UILabel()
        lb.text = "00.00"
        lb.font = UIFont(name: "Arial", size: 20)
        lb.textAlignment = .left
        
        // Habilitamos el uso de constraints
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    
    let longitudeLabel: UILabel = {
        let lb = UILabel()
        lb.text = "Longitud: "
        lb.font = UIFont(name: "Arial", size: 20)
        lb.textAlignment = .right
        
        
        // Habilitamos el uso de constraints
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    let longitudeActual: UILabel = {
        let lb = UILabel()
        lb.text = "00.00"
        lb.font = UIFont(name: "Arial", size: 20)
        lb.textAlignment = .left
        
        // Habilitamos el uso de constraints
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    let idUserTF : UITextField = {
        let tf = UITextField()
        tf.placeholder = "0"
        tf.font = UIFont(name: "Arial", size: 50)
        tf.textAlignment = .center
        
        // Habilitamos el uso de constraints
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()
    
    let boton : UIButton = {
        let bt = UIButton(type: .system)
        bt.setTitle("Iniciar GPS", for: .normal)
        bt.backgroundColor = UIColor.red
        bt.translatesAutoresizingMaskIntoConstraints = false
        
        bt.addTarget(self, action: #selector(getLocation), for: .touchUpInside)
        
        return bt
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Lista", style: .plain, target: self, action: #selector(listUsers))
        
        // Agregar elementos a la vista
        view.addSubview(latitudeLabel)
        view.addSubview(latitudeActual)
        view.addSubview(longitudeLabel)
        view.addSubview(longitudeActual)
        view.addSubview(idUserTF)
        view.addSubview(boton)
        
        ref = Database.database().reference()
        
        setupLayout()
        
    }
    
    func setupLayout(){
        
        longitudeLabel.rightAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        longitudeLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 100).isActive = true
        longitudeLabel.widthAnchor.constraint(equalToConstant: 200).isActive = true
        longitudeLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        longitudeActual.leftAnchor.constraint(equalTo: view.centerXAnchor, constant: 20).isActive = true
        longitudeActual.topAnchor.constraint(equalTo: view.topAnchor, constant: 100).isActive = true
        longitudeActual.widthAnchor.constraint(equalToConstant: 200).isActive = true
        longitudeActual.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        latitudeLabel.rightAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        latitudeLabel.topAnchor.constraint(equalTo: longitudeLabel.bottomAnchor, constant: 20).isActive = true
        latitudeLabel.widthAnchor.constraint(equalToConstant: 200).isActive = true
        latitudeLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        latitudeActual.leftAnchor.constraint(equalTo: view.centerXAnchor, constant: 20).isActive = true
        latitudeActual.topAnchor.constraint(equalTo: longitudeActual.bottomAnchor, constant: 20).isActive = true
        latitudeActual.widthAnchor.constraint(equalToConstant: 200).isActive = true
        latitudeActual.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        idUserTF.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        idUserTF.topAnchor.constraint(equalTo: latitudeActual.bottomAnchor, constant: 50).isActive = true
        idUserTF.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        idUserTF.heightAnchor.constraint(equalToConstant: 50)
        
        boton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        boton.topAnchor.constraint(equalTo: idUserTF.bottomAnchor, constant: 50).isActive = true
        boton.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        boton.heightAnchor.constraint(equalToConstant: 50)
    }
    
    @objc func getLocation(){
        let authStatus = CLLocationManager.authorizationStatus()
        
        if authStatus == .denied || authStatus == .restricted{
            showLocationServicesDeniedAlert()
            return
        }
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        //locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error ", error.localizedDescription)
        
        // localidad desconocida, estas perdido o el usuario no quizo dar permisos o hay un error en la red
        if (error as NSError).code == CLError.locationUnknown.rawValue{
            return
        }
        
        lastLocationError = error
        stopLocationManager()
        updateLabels()
    }

    
    // Esta funcion es parte del delagado y se ejecutara por aca actualización en la localidad
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let newLocation = locations.last!
        print("didUpdateLocations ", newLocation)
        
        if newLocation.timestamp.timeIntervalSinceNow < -5 {
            return
        }
        
        location = newLocation
        updateLabels()
        lastLocationError = nil
        
        // Actualizamos ahora en la BD
        if let location = location{
            let latitude = String(format: "%.8f", location.coordinate.latitude)
            let longitude = String(format: "%.8f", location.coordinate.longitude)
            let idUser = idUserTF.text
            
            let valuesGPS = ["idUser": idUser, "latitude":latitude, "longitude":longitude]
            self.ref.child("users").child(idUser!).updateChildValues(valuesGPS){ (error, databaseRef) in
                if error != nil{
                    print("error en base de datos")
                    return
                }
                print("localización actualizada")
            }
            
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus){
        if status == .authorizedWhenInUse || status == .authorizedAlways{
            locationManager.startUpdatingLocation()
            locationManager.allowsBackgroundLocationUpdates = true
            updatingLocation = true
        }
    }
    
    
    func showLocationServicesDeniedAlert() {
        let alert = UIAlertController(
            title: "Servicios de Localización desactivados",
            message: "Por favor habilite los servicios de localización para esta app en Configuración.",
            preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default,
                                     handler: nil)
        present(alert, animated: true, completion: nil)
        alert.addAction(okAction)
    }
    
    // Actualizamos las etiquedas en el UIViewController
    func updateLabels(){
        if let location = location{
            latitudeActual.text = String(format: "%.8f", location.coordinate.latitude)
            longitudeActual.text = String(format: "%.8f", location.coordinate.longitude)
        }else{
            latitudeActual.text = ""
            longitudeActual.text = ""
        }
    }
    
    func stopLocationManager(){
        if updatingLocation {
            locationManager.stopUpdatingLocation()
            locationManager.delegate = nil
            updatingLocation = false
        }
    }
    
    func startLocationManager(){
        if CLLocationManager.locationServicesEnabled(){
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
            updatingLocation = true
        }
    }
    
    @objc func listUsers(){
        self.navigationController?.pushViewController(ListaTableTableViewController(), animated: true)
    }


}

