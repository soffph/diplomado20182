# Notify Me, Notify You. Aha!
## User notifications on iOS 10

This code accompanies a talk presented at iOSConfSG in October 2016.


## Contact

Any questions, then feel free to gimme a shout on Twitter: [@iwantmyrealname](https://twitter.com/iwantmyrealname).


sam
