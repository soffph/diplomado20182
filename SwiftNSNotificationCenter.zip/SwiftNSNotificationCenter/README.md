# SwiftNSNotificationCenter

## Resources
This repository contains an example Xcode project for the blog post at [andrewcbancroft.com](http://www.andrewcbancroft.com) titled [Fundamentals of NSNotificationCenter in Swift](http://www.andrewcbancroft.com/2014/10/08/fundamentals-of-nsnotificationcenter-in-swift/).

## Compatibility
Verified that this repository's code works in Xcode 8 with Swift 3.0
